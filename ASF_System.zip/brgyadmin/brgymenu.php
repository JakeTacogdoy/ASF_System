<ul class="navbar-nav  sidebar sidebar-dark accordion"  id="accordionSidebar" 
style="background: linear-gradient(36deg, #515bf0,#515bf0);;">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../brgyadmin/Dashboard.php">
              
                <div class="sidebar-brand-text mx-3"><img src="../img/Swinesights.png" alt="" width="250px"></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
             <li class="nav-item active">
                <a class="nav-link" href="../brgyadmin/Dashboard.php">
                <i class="fa-solid fa-gauge" style="color: #ffffff;"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>


            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="../brgyadmin/listuser.php">
                <i class="fa-solid fa-clipboard-list"></i>
                    <span>Users</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="../brgyadmin/Account_user.php">
                <i class="fa-solid fa-user-plus"></i>
                    <span>Add Account</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="Userslist.php">
                <i class="fa-solid fa-message"></i>
                    <span>Message</span></a>
            </li>



            <li class="nav-item">
                <a class="nav-link" href="accepted_reports.php">
                <i class="fa-solid fa-message"></i>
                    <span>Accepted Reports</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="../brgyadmin/map.php">
                <i class="fa-solid fa-map-location-dot"></i>
                    <span>GIS Map</span></a>
            </li>



            

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

        </ul>